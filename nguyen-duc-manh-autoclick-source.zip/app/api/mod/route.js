export async function POST(){
return new Response("API ready");
}