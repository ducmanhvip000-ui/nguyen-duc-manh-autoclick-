export default function Home(){
return <main className="min-h-screen bg-black text-white flex items-center justify-center">
<div className="p-8 rounded-2xl bg-zinc-900">
<h1 className="text-3xl font-bold">Nguyễn Đức Mạnh AutoClick</h1>
<p>Upload JAR → Patch → Download</p>
</div>
</main>
}